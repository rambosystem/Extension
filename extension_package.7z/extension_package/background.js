chrome.runtime.onInstalled.addListener((details) => {
  // console.log("Detail", details.reason);
});
